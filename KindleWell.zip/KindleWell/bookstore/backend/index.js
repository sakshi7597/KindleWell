import express from "express";
import mongoose from "mongoose";
import dotenv from "dotenv";
import bookRoute from './route/book.route.js';
import userRoute from './route/user.route.js';
import cors from 'cors';

const app = express();

app.use(cors());
app.use(express.json());

dotenv.config();

// Correct the variable name to PORT
const port = process.env.PORT || 4000; // Use uppercase 'PORT'
const URI = process.env.MONGODB_URI; // Use correct variable name

// Connect to MongoDB
mongoose.connect(URI)
.then(() => {
    console.log("Connected to MongoDB");
})
.catch((error) => {
    console.error("Error connecting to MongoDB:", error);
});

// Defining routes
app.use("/book", bookRoute);
app.use("/user", userRoute);

// Define a simple route
/*app.get('/', (req, res) => {
    res.send('BookStore');
});*/

// Start the server
app.listen(port, () => {
    console.log(`Server is listening on port ${port}`);
});