import mongoose from "mongoose";

const userSchema = mongoose.Schema({
    fullname:{
        type:String,
        reguired:true

    },
    email:{
        type:String,
        reguired:true,
        unique:true

    },
    password:{
        type:String,
        reguired:true

    }
    
})
const User = mongoose.model("User", userSchema); 
export default User;