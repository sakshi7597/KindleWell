import React from 'react';
import Navbar from './Navbar';
import Footer from './Footer';

function Aboutus() {
  return (
    <>
      <Navbar />

      <br></br>

      <div className="mt-16">
        {/* About Our Project Section */}
        <div
          className="bg-cover bg-center p-8"
          style={{ backgroundImage: '' }}
        >
          <div className="text-center text-4xl font-bold text-black mb-4 dark:text-white">
            About Our Project
          </div>
          <div
            className="bg-white rounded-lg shadow-lg p-6 max-w-5xl mx-auto"
            style={{ marginBottom: '0' }} // Ensure no extra margin-bottom
          >
            <p className="text-red-700 text-center font-bold italic">
              "Welcome, fellow wanderers of words,
            </p>
            <p className="text-red-700 text-center font-bold italic">
              To a realm where stories unfold and dreams are stirred.
            </p>
            <p className="text-red-700 text-center font-bold italic">
              Step in, dear reader, let curiosity lead,
            </p>
            <p className="text-red-700 text-center font-bold italic">
              Where every page offers a new thought to heed."
            </p>
            <p className="text-gray-700 text-center mt-4">
              Our project is an online bookstore built with the MERN stack
              (MongoDB, Express.js, React.js, Node.js). It offers a
              user-friendly platform for browsing and purchasing books. The
              React front-end ensures an interactive experience, while the
              back-end, powered by Node.js and Express.js, manages data and
              transactions efficiently. MongoDB stores book and user data,
              ensuring fast access and scalability. The project aims to deliver
              a seamless, secure, and modern online shopping experience for book
              lovers.
            </p>
            <p className="text-gray-700 text-center font-bold mt-4">
              Sign up and Stay Updated.
            </p>
          </div>
        </div>

        <br></br>

        {/* Genres Section */}
        <div
          className="bg-white-100 py-4"
          style={{ marginTop: '0' }} // Ensure no extra margin-top
        >
          <div className="text-center text-4xl font-bold text-black mb-8 dark:text-white">
            Genres We Offer
          </div>
          <div className="flex flex-wrap justify-center gap-4 max-w-5xl mx-auto">
            {[
              'Fiction',
              'Mystery',
              'Romance',
              'Science Fiction',
              'Fantasy',
              'Biography',
              'History',
              'Self-Help',
              'Philosophy',
              "Children's Books",
            ].map((genre) => (
              <div
                key={genre}
                className="bg-white text-gray-800 font-semibold px-6 py-3 rounded-lg shadow-md hover:shadow-lg transition duration-300"
              >
                {genre}
              </div>
            ))}
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
}

export default Aboutus;