import React from 'react';

function Cards({ item }) {
  const cardStyle = {
    display: 'flex',
    flexDirection: 'column',
    height: '900px', // Set a fixed height for the card
    backgroundColor: 'white', // Card background color
    boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)', // Optional shadow for the card
    transition: 'transform 0.2s',
    overflow: 'hidden', 
    
  };

  const imageStyle = {
    width: '100%',
    height: '600px', // Set a fixed height for the image
    objectFit: 'cover', // Maintain aspect ratio
  };

  const cardBodyStyle = {
    flexGrow: 1, // Allow the card body to take up remaining space
    padding: '1rem',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'space-between', // Space out elements in the card body
  };

  return (
    <div className='mt-4 my-3 p-3 h-100'>
      <div
        className="card bg-base-100 w-92 shadow-xl hover:scale-105 duration-200 dark:bg-slate-900 dark:text-white dark:border"
        style={cardStyle}
      >
        <figure>
          <img
            src={item.image}
            alt="Shoes"
            style={imageStyle}
          />
        </figure>
        <div className="card-body   dark:bg-slate-900 dark:text-white  " style={cardBodyStyle}>
          <h2 className="card-title  dark:bg-slate-900 dark:text-white ">
            {item.name}
            <div className="badge badge-secondary">{item.category}</div>
          </h2>
          <p>{item.title}</p>
          <div className="card-actions justify-between  dark:bg-slate-900 dark:text-white ">
            <div className="badge badge-outline  dark:bg-slate-900 dark:text-white ">{item.price}</div>
            <div className="cursor-pointer px-2 py-1 rounded-full border-[2px] hover:bg-pink-500 hover:text-white duration-200 
            dark:bg-slate-900 dark:text-white 
            ">Buy now</div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Cards;