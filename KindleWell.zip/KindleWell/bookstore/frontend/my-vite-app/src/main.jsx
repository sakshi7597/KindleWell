import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App.jsx"; // Ensure App is correctly defined and exported
import "./index.css"; // Ensure styles are correctly defined
import { BrowserRouter } from "react-router-dom"; // Ensure react-router-dom is installed
import AuthProvider from "./context/AuthProvider.jsx"; // Ensure AuthProvider is correctly defined and exported

// Check if the root element exists
const rootElement = document.getElementById("root");
if (!rootElement) {
  console.error("No root element found. Make sure your index.html has a <div id='root'></div>.");
} else {
  ReactDOM.createRoot(rootElement).render(
    <BrowserRouter>
      <AuthProvider>
        <div className="dark:bg-slate-900 dark:text-white">
          <App />
        </div>
      </AuthProvider>
    </BrowserRouter>
  );
}
